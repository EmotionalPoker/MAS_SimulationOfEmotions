from tkinter import *
from PIL import ImageTk, Image
import re
import os
import sys
import random
import itertools
import time

root=Tk()

# the set of suit symbols
suit_symbols = ["♣", "♦", "♥", "♠"]
# the set of ranks
ranks = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]

class Card:
    """
    Card class to create and return a card object.
    """
    def __init__(self, value, suit):
        self.value = value
        self.suit = suit

    def return_card(self):
        """
        Returns card object in the format CardRank_CardSuit.
        """
        return "{}_{}".format(self.value, self.suit)


class Deck:
    """
    Deck class builds the deck of cards consisting of card objects in straight
    and/or shuffle format.
    """
    def __init__(self):
        self.cards = []

    def build_deck(self):
        """
        Builds the deck of cards in straight format.
        """
        for suit in ["♣", "♦", "♥", "♠"]:
            for value in range(2, 15):
                if value == 11:
                    value = "J"
                elif value == 12:
                    value = "Q"
                elif value == 13:
                    value = "K"
                elif value == 14:
                    value = "A"
                self.cards.append(Card(value, suit))

    def shuffle_deck(self):
        """
        Shuffles the deck of cards in a random format.
        """
        for _ in range(0, len(self.cards)):
            random_card = random.randint(0, len(self.cards) - 1)
            (self.cards[_], self.cards[random_card]) = (
                                        self.cards[random_card], self.cards[_])

    def return_deck(self):
        """
        Returns the deck of card objects in a list in straight and/or shuffle
        format.
        """
        return_deck = []
        for _ in self.cards:
            return_deck.append(_.return_card())
        return return_deck


class Player:
    """
    Class to manually add players to the poker game and draw and returns the
    players's hand cards.
    """
    def __init__(self):
        self.hand = []

    def draw_hand(self, _):
        """
        Draw cards from the deck for the player.
        """
        self.hand.append(_.pop())

    def return_hand(self):
        """
        Returns the player's hand cards.
        """
        return_hand = []
        for _ in self.hand:
            return_hand.append(_)
        return return_hand

class Poker:
    """
    Class defining poker rules, takes the player cards and the community cards
    as input for the class to be used by the individual check functions!
    """
    def __init__(self, communitycards, *player_cards):
        self.playercards = []
        self.communitycards = communitycards
        for items in player_cards:
            for item in items:
                self.playercards.append(item)
        # print(self.playercards)
        # print(self.communitycards)

    def royal_flush(self):
        """
        To check for a flush in the set, Takes the player cards and community
        cards as input, and checks for a flush among the players, and returns
        the players whose cards matches. Does not return any cards if
        multiple flush cards or no flush cards are detected.
        Also checks for the value of the cards are according to the rank
        ["10", "J", "Q", "K", "A"] returns the player whose cards matches,
        combing it with the above flush result to check for a ROYAL FLUSH,
        returns the player if winner else returns None and moves to the next
        check function!
        """
        suit = []
        playercommunitycards = []
        player = []
        flushcount = []
        playercount = []
        flushplayercount = []
        for item in self.playercards:
            playercommunitycards.append(item+self.communitycards)
        # print(playercommunitycards)
        for items in playercommunitycards:
            for item in items:
                player.append(item.split("_")[1])
            suit.append(player)
            player = []
        # print(suit)
        cardclass = ["♣", "♦", "♥", "♠"]
        for items in cardclass:
            for item in suit:
                flushcount.append(item.count(items))
            # print(flushcount)
            for position, item in enumerate(flushcount):
                if item >= 5:
                    playercount.append(position)
            # print(playercount)
            flushplayercount.append(playercount)
            playercount = []
            flushcount = []
        # print(flushplayercount)
        rank = ["10", "J", "Q", "K", "A"]
        count = 0
        value = []
        for items in playercommunitycards:
            for item in items:
                player.append(item.split("_")[0])
            value.append(player)
            player = []
        # print(value)
        royal = []
        for pos, items in enumerate(value):
            for ranking in rank:
                if ranking in items:
                    count += 1
            royal.append((pos, count))
            count = 0
        # print(royal)
        new_royal = []
        for items in royal:
            if items[1] == 5:
                new_royal.append(items[0])
        # print(new_royal)
        final_royal = []
        for item in new_royal:
            for items in flushplayercount:
                if item in items:
                    final_royal.append(item)
        for items in new_royal:
            return items

    def straight_flush(self):
        """
         To check for a flush in the set, Takes the player cards and community
         cards as input, and checks for a flush among the players, and returns
         the players whose cards matches. Does not return any cards if
         multiple flush cards or no flush cards are detected.
         Also checks for the value of the cards are according to the straight
         rank returns the player whose cards matches, combing it with the above
         flush result to check for a STRAIGHT FLUSH, returns the player if
         winner else returns None and moves to the next check function!
         """
        suit = []
        playercommunitycards = []
        player = []
        flushcount = []
        playercount = []
        flushplayercount = []
        for item in self.playercards:
            playercommunitycards.append(item+self.communitycards)
        # print(playercommunitycards)
        for items in playercommunitycards:
            for item in items:
                player.append(item.split("_")[1])
            suit.append(player)
            player = []
        # print(suit)
        cardclass = ["♣", "♦", "♥", "♠"]
        for items in cardclass:
            for item in suit:
                flushcount.append(item.count(items))
            # print(flushcount)
            for position, item in enumerate(flushcount):
                if item >= 5:
                    playercount.append(position)
            # print(playercount)
            flushplayercount.append(playercount)
            playercount = []
            flushcount = []
        # print(flushplayercount)
        value = []
        for items in playercommunitycards:
            for item in items:
                player.append(item.split("_")[0])
            value.append(player)
            player = []
        # print(value)
        rank = ["2", "3", "4", "5", "6", "7", "8", "9",
                "10", "J", "Q", "K", "A"]
        card_position = []
        playerp = []
        for items in value:
            for position, item in enumerate(rank):
                if item in items:
                    playerp.append(position)
            card_position.append(playerp)
            playerp = []
        # print(card_position)
        groups = []
        group = []
        for items in card_position:
            value1 = value2 = items[0]
            for item in items[1:]:
                if item == value2 + 1:
                    value2 = item
                else:
                    groups.append(value1 if value1 == value2 else
                                  (value1, value2))
                    value1 = value2 = item
            groups.append(value1 if value1 == value2 else (value1, value2))
            group.append(groups)
            groups = []
        # print(group)
        new_group = []
        player = []
        for items in group:
            for item in items:
                if type(item) is tuple:
                    player.append(item)
            new_group.append(player)
            player = []
        # print(new_group)
        straightplayer = []
        for pos, items in enumerate(new_group):
            if len(items) != 0:
                if items[0][-1] - items[0][0] == 4:
                    straightplayer.append(pos)
        # print(straightplayer)
        for item in straightplayer:
            for items in flushplayercount:
                if item in items:
                    return item
                else:
                    return None

    def four_of_a_kind(self):
        """
         To check for a four of a kind in the set, Takes the player cards and
         community cards as input, and checks for a four of a kind among the
         players, and returns the players whose cards matches. Does not return
         any cards if multiple or no four of a kinds are detected. Returns the
         player if winner else returns None and moves to the next check
         function!
         """
        value = []
        player = []
        playercommunitycards = []
        player = []
        for item in self.playercards:
            playercommunitycards.append(item+self.communitycards)
        # print(playercommunitycards)
        for items in playercommunitycards:
            for item in items:
                player.append(item.split("_")[0])
            value.append(player)
            player = []
        # print(value)
        new_value = []
        player = []
        for items in value:
            for value1, value2, value3, value4 in itertools.combinations(
                                                                    items, 4):
                player.append((value1, value2, value3, value4))
            new_value.append(player)
            player = []
        four_of_a_kind = []
        player = []
        for items in new_value:
            for item in items:
                if (item[0] == item[1] and item[1] == item[2] and item[2] ==
                        item[3]):
                    player.append((item[0], item[1], item[2], item[3]))
            four_of_a_kind.append(player)
            player = []
        # print(four_of_a_kind)
        new_four_of_a_kind = []
        for pos, items in enumerate(four_of_a_kind):
            if len(items) >= 1:
                new_four_of_a_kind.append(pos)
        # print(new_four_of_a_kind)
        if len(new_four_of_a_kind) == 1:
            return new_four_of_a_kind[0]
        else:
            return None

    def full_house(self):
        """
        To check for a three of a kind in the set, Takes the player cards and
        community cards as input, and checks for a three of a kind among the
        players, and returns the players whose cards matches. Does not return
        any cards if multiple or no three of a kinds are detected. Returns the
        player if winner else returns None and moves to the next check
        function!
        To check for a highest pair in the set, Takes the player cards and
        community cards as input, and checks for the two pairs among the
        players and returns the players value. Does not return any cards if
        multiple or no two pair cards are detected, it is then directed to the
        next check function!
        """
        value = []
        player = []
        playercommunitycards = []
        player = []
        for item in self.playercards:
            playercommunitycards.append(item+self.communitycards)
        # print(playercommunitycards)
        for items in playercommunitycards:
            for item in items:
                player.append(item.split("_")[0])
            value.append(player)
            player = []
        # print(value)
        new_value = []
        player = []
        for items in value:
            for value1, value2, value3 in itertools.combinations(items, 3):
                player.append((value1, value2, value3))
            new_value.append(player)
            player = []
        three_of_a_kind = []
        player = []
        for items in new_value:
            for item in items:
                if item[0] == item[1] and item[1] == item[2]:
                    player.append((item[0], item[1], item[2]))
            three_of_a_kind.append(player)
            player = []
        # print(three_of_a_kind)
        new_three_of_a_kind = []
        for pos, items in enumerate(three_of_a_kind):
            if len(items) >= 1:
                new_three_of_a_kind.append(pos)
        # print(new_three_of_a_kind)
        rank = ["2", "3", "4", "5", "6", "7", "8", "9",
                "10", "J", "Q", "K", "A"]
        playervalue = []
        communityvalue = []
        player = []
        for items in self.playercards:
            for item in items:
                player.append(item.split("_")[0])
            playervalue.append(player)
            player = []
        for item in self.communitycards:
            communityvalue.append(item.split("_")[0])
        # print(playervalue)
        # print(communityvalue)
        new_value = []
        player = []
        for pos, items in enumerate(playervalue):
            if items[0] == items[1]:
                player.append([pos, items[0]])
            for item in items:
                if item in communityvalue:
                    player.append([pos, item])
            new_value.append(player)
            player = []
        # print(new_value)
        pair_rank = []
        player = []
        for items in new_value:
            for item in items:
                for pos, ranking in enumerate(rank):
                    if ranking == item[1]:
                        player.append([pos, item])
                pair_rank.append(player)
                player = []
        pair_rank = sorted(pair_rank)
        # print(pair_rank)
        count = 0
        playercount = []
        player = []
        for items in pair_rank:
            for item in new_three_of_a_kind:
                if item == items[0][1][0]:
                    count += 1
            player.append(count)
            playercount.append(player)
            player = []
            count = 0
        # print(playercount)
        if len(playercount) == 1:
            for pos, items in enumerate(playercount):
                return pos
        else:
            return None

    def straight(self):
        """
         Checks for the value of the cards are according to the straight
         rank and returns the player whose cards matches, to check for a
         STRAIGHT, returns the player if winner else returns None and moves
         to the next check function!
         """
        playercommunitycards = []
        player = []
        for item in self.playercards:
            playercommunitycards.append(item+self.communitycards)
        # print(playercommunitycards)
        value = []
        for items in playercommunitycards:
            for item in items:
                player.append(item.split("_")[0])
            value.append(player)
            player = []
        # print(value)
        rank = ["2", "3", "4", "5", "6", "7", "8", "9",
                "10", "J", "Q", "K", "A"]
        card_position = []
        playerp = []
        for items in value:
            for position, item in enumerate(rank):
                if item in items:
                    playerp.append(position)
            card_position.append(playerp)
            playerp = []
        # print(card_position)
        groups = []
        group = []
        for items in card_position:
            value1 = value2 = items[0]
            for item in items[1:]:
                if item == value2 + 1:
                    value2 = item
                else:
                    groups.append(value1 if value1 == value2 else
                                  (value1, value2))
                    value1 = value2 = item
            groups.append(value1 if value1 == value2 else (value1, value2))
            group.append(groups)
            groups = []
        # print(group)
        new_group = []
        player = []
        for items in group:
            for item in items:
                if type(item) is tuple:
                    player.append(item)
            new_group.append(player)
            player = []
        # print(new_group)
        straightplayer = []
        for pos, items in enumerate(new_group):
            if len(items) != 0:
                if items[0][-1] - items[0][0] == 4:
                    straightplayer.append(pos)
        # print(straightplayer)
        if len(straightplayer) == 1:
            return straightplayer[0]
        else:
            return None

    def flush(self):
        """
        To check for a flush in the set, Takes the player cards and community
        cards as input, and checks for a flush among the players, and returns
        the players and flush cards value. Does not return any cards if
        multiple flush cards or no flush cards are detected, and is then
        directed to the next check function!
        """
        suit = []
        playercommunitycards = []
        player = []
        flushcount = []
        playercount = []
        flushplayercount = []
        for item in self.playercards:
            playercommunitycards.append(item+self.communitycards)
        # print(playercommunitycards)
        for items in playercommunitycards:
            for item in items:
                player.append(item.split("_")[1])
            suit.append(player)
            player = []
        # print(suit)
        cardclass = ["♣", "♦", "♥", "♠"]
        for items in cardclass:
            for item in suit:
                flushcount.append(item.count(items))
            # print(flushcount)
            for position, item in enumerate(flushcount):
                if item > 5:
                    playercount.append(position)
            # print(playercount)
            flushplayercount.append(playercount)
            playercount = []
            flushcount = []
        # print(flushplayercount)
        finalflush = []
        for items in flushplayercount:
            if len(items) == 1:
                finalflush.append(items)
        # print(finalflush)
        if len(finalflush) != 0:
            for items in finalflush:
                if len(items) == 1:
                    return items[0]
                else:
                    return None

    def three_of_a_kind(self):
        """
         To check for a three of a kind in the set, Takes the player cards and
         community cards as input, and checks for a three of a kind among the
         players, and returns the players whose cards matches. Does not return
         any cards if multiple or no three of a kinds are detected. Returns the
         player if winner else returns None and moves to the next check
         function!
         """
        value = []
        player = []
        playercommunitycards = []
        player = []
        for item in self.playercards:
            playercommunitycards.append(item+self.communitycards)
        # print(playercommunitycards)
        for items in playercommunitycards:
            for item in items:
                player.append(item.split("_")[0])
            value.append(player)
            player = []
        # print(value)
        new_value = []
        player = []
        for items in value:
            for value1, value2, value3 in itertools.combinations(items, 3):
                player.append((value1, value2, value3))
            new_value.append(player)
            player = []
        three_of_a_kind = []
        player = []
        for items in new_value:
            for item in items:
                if item[0] == item[1] and item[1] == item[2]:
                    player.append((item[0], item[1], item[2]))
            three_of_a_kind.append(player)
            player = []
        # print(three_of_a_kind)
        new_three_of_a_kind = []
        for pos, items in enumerate(three_of_a_kind):
            if len(items) >= 1:
                new_three_of_a_kind.append(pos)
        # print(new_three_of_a_kind)
        if len(new_three_of_a_kind) == 1:
            return new_three_of_a_kind[0]
        else:
            return None

    def two_pair(self):
        """
        To check for a two pair in the set, Takes the player cards and
        community cards as input, and checks for the two pairs among the
        players and returns the players value. Does not return any cards if
        multiple or no two pair cards are detected, it is then directed to the
        next check function!
        """
        playervalue = []
        communityvalue = []
        player = []
        for items in self.playercards:
            for item in items:
                player.append(item.split("_")[0])
            playervalue.append(player)
            player = []
        for item in self.communitycards:
            communityvalue.append(item.split("_")[0])
        # print(playervalue)
        # print(communityvalue)
        new_value = []
        player = []
        for pos, items in enumerate(playervalue):
            if items[0] == items[1]:
                player.append([pos, items[0]])
            for item in items:
                if item in communityvalue:
                    player.append([pos, item])
            new_value.append(player)
            player = []
        # print(new_value)
        final_value = []
        for items in new_value:
            if len(items) == 2:
                final_value.append(items[0][0])
        # print(final_value)
        if len(final_value) == 1:
            return final_value[0]
        else:
            return None

    def pair(self):
        """
        To check for a highest pair in the set, Takes the player cards and
        community cards as input, and checks for the two pairs among the
        players and returns the players value. Does not return any cards if
        multiple or no two pair cards are detected, it is then directed to the
        next check function!
        """
        rank = ["2", "3", "4", "5", "6", "7", "8", "9",
                "10", "J", "Q", "K", "A"]
        playervalue = []
        communityvalue = []
        player = []
        for items in self.playercards:
            for item in items:
                player.append(item.split("_")[0])
            playervalue.append(player)
            player = []
        for item in self.communitycards:
            communityvalue.append(item.split("_")[0])
        # print(playervalue)
        # print(communityvalue)
        new_value = []
        player = []
        for pos, items in enumerate(playervalue):
            if items[0] == items[1]:
                player.append([pos, items[0]])
            for item in items:
                if item in communityvalue:
                    player.append([pos, item])
            new_value.append(player)
            player = []
        # print(new_value)
        pair_rank = []
        player = []
        for items in new_value:
            for item in items:
                for pos, ranking in enumerate(rank):
                    if ranking == item[1]:
                        player.append([pos, item])
                pair_rank.append(player)
                player = []
        pair_rank = sorted(pair_rank)
        # print(pair_rank)
        if len(pair_rank) == 1:
            return pair_rank[0][0][1][0]
        elif len(pair_rank) > 1:
            if pair_rank[-2][0][0] != pair_rank[-1][0][0]:
                return pair_rank[-1][0][1][0]
            else:
                return None
        else:
            return None

    def high_card(self):
        """
        To check the highest card in the set, Takes the player cards as input
        (Just the players cards and excluding the community cards.), and checks
        for the high cards among the players, and returns the players and high
        cards value. Does not return any cards if multiple high cards are
        detected, it is then directed to the second high card function.
        """
        rank = ["2", "3", "4", "5", "6", "7", "8", "9",
                "10", "J", "Q", "K", "A"]
        player = []
        value = []
        card_rank = []
        final_card_rank = []
        for items in self.playercards:
            for item in items:
                player.append(item.split("_")[0])
            value.append(player)
            player = []
        # print(value)
        for items in value:
            value1, value2 = items[0], items[1]
            for position, item in enumerate(rank):
                if item == value1:
                    player.append((position, value1))
                elif item == value2:
                    player.append((position, value2))
            if len(player) > 1:
                if player[0][0] > player[1][0]:
                    card_rank.append(player[0])
                elif player[0][0] < player[1][0]:
                    card_rank.append(player[1])
            else:
                card_rank.append(player[0])
            player = []
        # print(card_rank)
        new_card_rank = sorted(card_rank)
        # print(new_card_rank)
        for position, item in enumerate(card_rank):
            if new_card_rank[-1] == item:
                final_card_rank.append((position, item))
        # print(final_card_rank)
        if len(final_card_rank) == 1:
            return final_card_rank[0][0]
        else:
            return None

# method to get suit name based in the suit symbol
def get_suit_name(suit_symbol):
    # if suit symbol is clubs
    if( suit_symbol == "♣"):
        return "C"
    # if suit symbol is diamonds
    if( suit_symbol == "♦"):
        return "D"
    # if suit symbol is Hearts
    if( suit_symbol == "♥"):
        return "H"
    # if suit symbol is Spades
    if( suit_symbol == "♠"):
        return "S"
        
# get name of the file based on the suit and the rank
def get_card_image(suit_symbol,rank):
    # get the suit
    suit = get_suit_name(suit_symbol)
    # the file name
    file_name= ""
    if( rank == "10" or rank == "J" or rank == "Q" or rank == "K" or rank == "A" ):
        file_name = "image/" + suit + rank + ".png"
    else:
        file_name = "image/" + suit + "0" + rank + ".png"
        
    # create an image out of this file
    image = Image.open(file_name)
    # return the image
    return image
    
# mthod to resize the image and rget photo image
def get_resized_photo_image(image,width,height):
    # resize
    image = image.resize((width,height), Image.ANTIALIAS)
    # get photo image
    photo_image = ImageTk.PhotoImage(image)
    return photo_image
    
# method to get photo i,ages based on the name of the card

# the set of player cards


# the player card images
player_card_images = []
# the community card images
community_card_images = []

# the players
players = []
# initial player coins
initial_player_coins = []
# final player coins
final_player_coins = []
# the amount in pot
pot_amount = 1000

# get the player count
player_count = int( sys.argv[1] )
# the deck to be used
deck = Deck()
deck.build_deck()
deck.shuffle_deck()
deck.shuffle_deck()
shuffle_deck = deck.return_deck()

# create players
for i in range(player_count):
    players.append(Player())
    initial_player_coins.append(StringVar())
    final_player_coins.append(StringVar())

# draw 2 cards for each player
for i in range(player_count):
    players[i].draw_hand(shuffle_deck)
    players[i].draw_hand(shuffle_deck)
    initial_player_coins[i].set("0")
    final_player_coins[i].set("0")

# get community cards
community_cards = Player()
community_cards.draw_hand(shuffle_deck)
community_cards.draw_hand(shuffle_deck)
community_cards.draw_hand(shuffle_deck)
community_cards.draw_hand(shuffle_deck)
community_cards.draw_hand(shuffle_deck)

# the size to resize the image to
width = 50
height = 75
# add images of the cards
for i in range(player_count):
    photo_images = []
    for card in players[i].return_hand():
        image = get_card_image( card[len(card) - 1] ,card[:len(card) - 2] )
        photo_images.append(get_resized_photo_image(image,width,height))
    player_card_images.append(photo_images)

# add community cards and their images
for i in range(len(community_cards.return_hand())):
    card = community_cards.return_hand()[i]
    image = get_card_image( card[len(card) - 1] ,card[:len(card) - 2] )
    community_card_images.append(get_resized_photo_image(image,width,height))
    
# the row number
row = 0
Label(root, text = "Community cards :").grid(row=row, column=0)
# increment row
row += 1

# display community cards
for i in range(len(community_card_images)):
    Label(root, image = community_card_images[i]).grid(row=row, column=i+1)
# increment row
row += 1


for i in range(player_count):
    # the column number
    column_number = 0
    # label
    Label(root, text = "Player " + str(i+1) + " cards : ").grid(row=row, column=column_number)
    # increment column numner
    column_number += 1
    
    # add cards to it
    for j in range(len(player_card_images[i])):
        Label(root, image = player_card_images[i][j]).grid(row=row, column=column_number)
        # increment column numner
        column_number += 1
    # increment row
    row += 1
    
# show winner
winner = 1
    
# set row to 2
row = 2
# show pot
pot_image = Image.open("image/pot.png")
# resize pot image
pot_image = pot_image.resize((width,height), Image.ANTIALIAS)
# get photo image
pot_photo = ImageTk.PhotoImage(pot_image)
# Label(root, text = "        Pot:        ").grid(row=1, column=6)
Label(root, image = pot_photo ).grid(row=row, column=6)
# increment row
row += 1
# showpot amount
Label(root, text = ("Pot:\n$" + str(pot_amount))).grid(row=row, column=6)
# increment row
row += 1
# show winner
Label(root, text = "Player " + str(winner) + "\nwins").grid(row=player_count + 2, column=6)


# set the coins
row = 1
Label(root, text = "Initial Coins").grid(row=row, column=7)
Label(root, text = "Final Coins").grid(row=row, column=8)
# increment row
row += 1
# add all the coins data as well
for i in range(player_count):
    Label(root, textvariable = initial_player_coins[i]).grid(row=row, column=7)
    Label(root, textvariable = final_player_coins[i] ).grid(row=row, column=8)
    # increment row
    row += 1
    
root.mainloop()

